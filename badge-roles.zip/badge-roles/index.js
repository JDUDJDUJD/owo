const {manager} = require("discord-autorole-badges")
const {discord} = require("discord.js")

const client = new discord.Client({ intents: 32767 })

let manager = new Manager(client, {
    DISCORD_EMPLOYEE: "903651072915161149",
    PARTNERED_SERVER_OWNER: "903651072915161149",
    HYPESQUAD_EVENTS: "903651078514573312",
    BUGHUNTER_LEVEL_1: "903651078514573312",
    HOUSE_BRAVERY: "903651075570139147",
    HOUSE_BRILLIANCE: "903651069631029279",
    HOUSE_BALANCE: "903650874407149648",
    EARLY_SUPPORTER: "903651086118826004",
    TEAM_USER: "903651086118826004",
    BUGHUNTER_LEVEL_2: "903651086118826004",
    VERIFIED_BOT: "903872324867084288",
    EARLY_VERIFIED_BOT_DEVELOPER: "903651078514573312",
    DISCORD_CERTIFIED_MODERATOR: "903651072915161149",

}) //kod ve bu bölüm aşşağıdadır, id yazmak ile uğraşmamak için yapıştırdım

client.on("messageCreate", async(message) => {
    if (message.guild.id != "760511134079254610") return;

    const member = msg.member
    console.log("badge verildi: " + message.author.username)
     await manager.setRole(member);
})

client.on("guildMemberAdd", async(member) => {
    if (member.guild.id != "760511134079254610") return;
await manager.setRole(member)
})

client.on("ready", () => {
    console.log("bot hazır")
})

client.login("token.")